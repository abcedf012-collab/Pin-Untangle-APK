import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import JSZip from 'jszip';
import path from 'path';
import {defineConfig, type Plugin} from 'vite';

const ROOT_PROJECT_FILES = [
  '.env.example',
  '.gitignore',
  'capacitor.config.ts',
  'index.html',
  'metadata.json',
  'package.json',
  'tsconfig.json',
  'vite.config.ts',
];

const EXCLUDED_ANDROID_SEGMENTS = new Set([
  'build',
  '.gradle',
  'capacitor-cordova-android-plugins',
]);

function addDirectoryToZip(
  zip: JSZip,
  absDir: string,
  relBase: string,
  filterFn?: (relPath: string, isDir: boolean) => boolean
): void {
  if (!fs.existsSync(absDir)) return;
  const entries = fs.readdirSync(absDir, {withFileTypes: true});
  for (const entry of entries) {
    const absPath = path.join(absDir, entry.name);
    const relPath = relBase ? `${relBase}/${entry.name}` : entry.name;
    const isDir = entry.isDirectory();
    if (filterFn && !filterFn(relPath, isDir)) continue;
    if (isDir) {
      addDirectoryToZip(zip, absPath, relPath, filterFn);
    } else if (entry.isFile()) {
      zip.file(relPath, fs.readFileSync(absPath));
    }
  }
}

async function generateAndroidProjectZipBuffer(rootDir: string): Promise<Buffer> {
  const zip = new JSZip();

  for (const file of ROOT_PROJECT_FILES) {
    const abs = path.join(rootDir, file);
    if (fs.existsSync(abs) && fs.statSync(abs).isFile()) {
      zip.file(file, fs.readFileSync(abs));
    }
  }

  addDirectoryToZip(zip, path.join(rootDir, '.github'), '.github');
  addDirectoryToZip(zip, path.join(rootDir, 'src'), 'src');

  const standalonePublic = path.join(rootDir, 'public', 'pin-untangle.html');
  if (fs.existsSync(standalonePublic)) {
    zip.file('public/pin-untangle.html', fs.readFileSync(standalonePublic));
  }

  addDirectoryToZip(zip, path.join(rootDir, 'android'), 'android', (relPath, isDir) => {
    const parts = relPath.split('/');
    for (const part of parts) {
      if (EXCLUDED_ANDROID_SEGMENTS.has(part)) return false;
    }
    if (relPath.startsWith('android/app/src/main/assets')) return false;
    if (!isDir) {
      if (relPath.endsWith('.apk') || relPath.endsWith('.aab')) return false;
      if (path.basename(relPath) === 'local.properties') return false;
    }
    return true;
  });

  return zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: {level: 6},
  });
}

function androidProjectZipPlugin(): Plugin {
  const rootDir = __dirname;
  return {
    name: 'android-project-zip-export',
    configureServer(server) {
      server.middlewares.use('/pin-untangle-android-project.zip', async (_req, res, next) => {
        try {
          const buffer = await generateAndroidProjectZipBuffer(rootDir);
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/zip');
          res.setHeader('Content-Disposition', 'attachment; filename="pin-untangle-android-startio.zip"');
          res.end(buffer);
        } catch (err) {
          next(err);
        }
      });
    },
    async closeBundle(error?: Error) {
      if (error) return;
      const distDir = path.resolve(rootDir, 'dist');
      if (!fs.existsSync(distDir)) return;
      const buffer = await generateAndroidProjectZipBuffer(rootDir);
      fs.writeFileSync(path.join(distDir, 'pin-untangle-android-project.zip'), buffer);
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      // Copies src/assets into dist/ so root-relative URLs like
      // "/src/assets/images/..." (e.g. generate_image output) still resolve
      // in production builds. Do not remove.
      {
        name: 'copy-unbundled-src-assets',
        apply: 'build',
        closeBundle(error?: Error): void {
          if (error) {
            return;
          }
          const distDir = path.resolve(__dirname, 'dist');
          const srcAssets = path.resolve(__dirname, 'src/assets');
          const distAssets = path.resolve(distDir, 'src/assets');
          if (fs.existsSync(distDir) && fs.existsSync(srcAssets)) {
            fs.cpSync(srcAssets, distAssets, {recursive: true, force: true});
          }
        },
      },
      androidProjectZipPlugin(),
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
