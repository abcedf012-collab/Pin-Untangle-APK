import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.pinuntangle.game',
  appName: 'Pin Untangle',
  webDir: 'dist',
  android: {
    backgroundColor: '#F2F4F7',
  },
};

export default config;
