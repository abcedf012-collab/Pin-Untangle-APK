import React, { useEffect, useRef } from 'react';
import {
  BOARD_H,
  BOARD_W,
  PIN_PALETTE,
  Pin,
  Point,
  findTappedPin,
  getPinEndpoints,
} from '../game/puzzle';

interface SparkEffect {
  x: number;
  y: number;
  life: number;
  maxLife: number;
}

interface PinBoardProps {
  pins: Pin[];
  hintPinId: number | null;
  disabled: boolean;
  shaking: boolean;
  onPinTap: (pinId: number) => void;
  onAnimationTick: (dt: number) => void;
  impactEvent: { x: number; y: number; key: number } | null;
}

export const PinBoard: React.FC<PinBoardProps> = ({
  pins,
  hintPinId,
  disabled,
  shaking,
  onPinTap,
  onAnimationTick,
  impactEvent,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const pinsRef = useRef<Pin[]>(pins);
  const hintRef = useRef<number | null>(hintPinId);
  const sparksRef = useRef<SparkEffect[]>([]);
  const tickCallbackRef = useRef(onAnimationTick);

  pinsRef.current = pins;
  hintRef.current = hintPinId;
  tickCallbackRef.current = onAnimationTick;

  useEffect(() => {
    if (impactEvent) {
      sparksRef.current.push({
        x: impactEvent.x,
        y: impactEvent.y,
        life: 0.36,
        maxLife: 0.36,
      });
    }
  }, [impactEvent]);

  useEffect(() => {
    let rafId = 0;
    let lastTime = performance.now();

    const renderFrame = (now: number) => {
      const dt = Math.min(0.05, (now - lastTime) / 1000);
      lastTime = now;

      tickCallbackRef.current(dt);

      // Update sparks
      sparksRef.current = sparksRef.current
        .map((s) => ({ ...s, life: s.life - dt }))
        .filter((s) => s.life > 0);

      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
          const targetW = Math.round(BOARD_W * dpr);
          const targetH = Math.round(BOARD_H * dpr);
          if (canvas.width !== targetW || canvas.height !== targetH) {
            canvas.width = targetW;
            canvas.height = targetH;
          }

          ctx.save();
          ctx.scale(dpr, dpr);

          // 1. Clean tactile pegboard surface
          ctx.fillStyle = '#FFFFFF';
          ctx.fillRect(0, 0, BOARD_W, BOARD_H);

          // Subtle pegboard dot matrix
          ctx.fillStyle = '#E2E8F0';
          const step = 24;
          for (let gx = step; gx < BOARD_W; gx += step) {
            for (let gy = step; gy < BOARD_H; gy += step) {
              ctx.beginPath();
              ctx.arc(gx, gy, 1.5, 0, Math.PI * 2);
              ctx.fill();
            }
          }

          // Subtle inner border frame
          ctx.strokeStyle = '#E2E8F0';
          ctx.lineWidth = 2;
          ctx.strokeRect(1, 1, BOARD_W - 2, BOARD_H - 2);

          // 2. Draw all active/animating pins
          const currentPins = pinsRef.current;
          for (const pin of currentPins) {
            if (pin.status === 'removed') continue;

            const theme = PIN_PALETTE[pin.colorIndex % PIN_PALETTE.length];
            const seg = getPinEndpoints(pin, pin.offset);
            const dx = Math.cos(pin.angle);
            const dy = Math.sin(pin.angle);
            const r = pin.radius;

            // Fade out slightly only when far outside the board
            const midX = (seg.a.x + seg.b.x) * 0.5;
            const midY = (seg.a.y + seg.b.y) * 0.5;
            const outDist = Math.max(
              0,
              -midX,
              midX - BOARD_W,
              -midY,
              midY - BOARD_H
            );
            const alpha = Math.max(0, 1 - outDist / 110);
            if (alpha <= 0.01) continue;

            ctx.save();
            ctx.globalAlpha = alpha;

            // Hint glow ring
            if (hintRef.current === pin.id && pin.status === 'idle') {
              const pulse = 0.5 + 0.5 * Math.sin(now * 0.007);
              ctx.save();
              ctx.lineCap = 'round';
              ctx.strokeStyle = `rgba(37, 99, 235, ${0.28 + pulse * 0.35})`;
              ctx.lineWidth = r * 2 + 12;
              ctx.beginPath();
              ctx.moveTo(seg.a.x, seg.a.y);
              ctx.lineTo(seg.b.x, seg.b.y);
              ctx.stroke();
              ctx.restore();
            }

            // Soft physical drop shadow
            ctx.save();
            ctx.lineCap = 'round';
            ctx.strokeStyle = pin.status === 'exiting' ? 'rgba(15, 23, 42, 0.22)' : 'rgba(15, 23, 42, 0.14)';
            ctx.lineWidth = r * 2;
            ctx.beginPath();
            ctx.moveTo(seg.a.x, seg.a.y + 4);
            ctx.lineTo(seg.b.x, seg.b.y + 4);
            ctx.stroke();
            ctx.restore();

            // Outer border stroke
            ctx.save();
            ctx.lineCap = 'round';
            ctx.strokeStyle = pin.flashTimer > 0 ? '#DC2626' : theme.border;
            ctx.lineWidth = r * 2 + 2.5;
            ctx.beginPath();
            ctx.moveTo(seg.a.x, seg.a.y);
            ctx.lineTo(seg.b.x, seg.b.y);
            ctx.stroke();
            ctx.restore();

            // Main pin capsule body
            ctx.save();
            ctx.lineCap = 'round';
            ctx.strokeStyle = pin.flashTimer > 0 ? '#EF4444' : theme.body;
            ctx.lineWidth = r * 2;
            ctx.beginPath();
            ctx.moveTo(seg.a.x, seg.a.y);
            ctx.lineTo(seg.b.x, seg.b.y);
            ctx.stroke();
            ctx.restore();

            // Specular inner ridge for tactile plastic/enamel feel
            ctx.save();
            ctx.lineCap = 'round';
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.32)';
            ctx.lineWidth = 4;
            const perpX = -dy * (r * 0.35);
            const perpY = dx * (r * 0.35);
            ctx.beginPath();
            ctx.moveTo(seg.a.x + perpX, seg.a.y + perpY);
            ctx.lineTo(seg.b.x + perpX, seg.b.y + perpY);
            ctx.stroke();
            ctx.restore();

            // Tail rivet dot
            ctx.save();
            ctx.fillStyle = 'rgba(255, 255, 255, 0.55)';
            ctx.beginPath();
            ctx.arc(seg.a.x, seg.a.y, 3.2, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();

            // Directional pin head cap at B
            ctx.save();
            ctx.translate(seg.b.x, seg.b.y);
            ctx.rotate(pin.angle);

            ctx.fillStyle = pin.flashTimer > 0 ? '#B91C1C' : theme.head;
            ctx.beginPath();
            ctx.arc(0, 0, r - 1.5, 0, Math.PI * 2);
            ctx.fill();

            // Crisp directional chevron inside the head
            ctx.strokeStyle = '#FFFFFF';
            ctx.lineWidth = 2.6;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.beginPath();
            ctx.moveTo(-3.5, -5);
            ctx.lineTo(3.5, 0);
            ctx.lineTo(-3.5, 5);
            ctx.stroke();

            ctx.restore();
            ctx.restore();
          }

          // 3. Draw collision impact sparks
          for (const spark of sparksRef.current) {
            const p = 1 - spark.life / spark.maxLife;
            const radius = 8 + p * 26;
            const opacity = Math.max(0, 1 - p);

            ctx.save();
            ctx.strokeStyle = `rgba(220, 38, 38, ${opacity})`;
            ctx.lineWidth = 3 * (1 - p * 0.5);
            ctx.beginPath();
            ctx.arc(spark.x, spark.y, radius, 0, Math.PI * 2);
            ctx.stroke();

            ctx.fillStyle = `rgba(239, 68, 68, ${opacity * 0.35})`;
            ctx.beginPath();
            ctx.arc(spark.x, spark.y, radius * 0.55, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
          }

          ctx.restore();
        }
      }

      rafId = requestAnimationFrame(renderFrame);
    };

    rafId = requestAnimationFrame(renderFrame);
    return () => cancelAnimationFrame(rafId);
  }, []);

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (disabled) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return;

    const pt: Point = {
      x: ((e.clientX - rect.left) / rect.width) * BOARD_W,
      y: ((e.clientY - rect.top) / rect.height) * BOARD_H,
    };

    const hit = findTappedPin(pinsRef.current, pt);
    if (hit) {
      onPinTap(hit.id);
    }
  };

  return (
    <div
      className={`relative w-full max-w-[380px] mx-auto rounded-3xl bg-white shadow-[0_14px_38px_-12px_rgba(15,23,42,0.16)] border border-slate-200 overflow-hidden select-none ${
        shaking ? 'animate-board-shake' : ''
      }`}
      style={{ aspectRatio: `${BOARD_W} / ${BOARD_H}` }}
    >
      <canvas
        ref={canvasRef}
        onPointerDown={handlePointerDown}
        className="w-full h-full block cursor-pointer touch-manipulation"
        aria-label="Plateau de jeu Pin Untangle"
      />
    </div>
  );
};
