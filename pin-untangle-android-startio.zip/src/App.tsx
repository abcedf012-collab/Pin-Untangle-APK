import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Check,
  Coins,
  Copy,
  Download,
  FolderArchive,
  Heart,
  HelpCircle,
  Lightbulb,
  Play,
  RotateCcw,
  ShieldAlert,
  Smartphone,
  Tv,
  Volume2,
  VolumeX,
} from 'lucide-react';
import JSZip from 'jszip';
import standaloneHtml from './game/pin-untangle.html?raw';
import workflowTemplate from '../.github/workflows/build-android.yml?raw';
import { PinBoard } from './components/PinBoard';
import {
  Pin,
  findBlockingPin,
  generateLevelPins,
  getFreePinIds,
  getLevelConfig,
} from './game/puzzle';
import { sound } from './game/sound';
import {
  initStartIo,
  isNativeMobile,
  showNativeInterstitial,
  showNativeRewardedAd,
} from './game/startio';

const MAX_LIVES = 5;
const LIFE_COST = 50;
const AD_DURATION_SEC = 10;
const AD_LIFE_REWARD = 2;
const COIN_TASK_DURATION_SEC = 6;
const COIN_TASK_REWARD = 25;
const DAILY_COIN_LIMIT = 50;
const HINT_COST = 15;
const STORAGE_KEY = 'pin_untangle_save_v1';

type GamePhase = 'PLAYING' | 'LEVEL_CLEAR' | 'GAME_OVER';
type RewardMode = null | { type: 'AD_LIVES' | 'EARN_COINS'; totalSec: number; elapsed: number; amount?: number };

interface SavedProgress {
  level: number;
  coins: number;
  lives: number;
  clearedTotal: number;
  dailyBonusDate: string;
  dailyBonusEarned: number;
}

function getTodayKey(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function loadSavedProgress(): SavedProgress {
  const today = getTodayKey();
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<SavedProgress>;
      const sameDay = parsed.dailyBonusDate === today;
      return {
        level: typeof parsed.level === 'number' && parsed.level >= 1 ? parsed.level : 1,
        coins: typeof parsed.coins === 'number' && parsed.coins >= 0 ? parsed.coins : 60,
        lives:
          typeof parsed.lives === 'number'
            ? Math.max(0, Math.min(MAX_LIVES, parsed.lives))
            : MAX_LIVES,
        clearedTotal: typeof parsed.clearedTotal === 'number' ? parsed.clearedTotal : 0,
        dailyBonusDate: today,
        dailyBonusEarned:
          sameDay && typeof parsed.dailyBonusEarned === 'number'
            ? Math.max(0, Math.min(DAILY_COIN_LIMIT, parsed.dailyBonusEarned))
            : 0,
      };
    }
  } catch {
    // Ignore storage errors
  }
  return {
    level: 1,
    coins: 60,
    lives: MAX_LIVES,
    clearedTotal: 0,
    dailyBonusDate: today,
    dailyBonusEarned: 0,
  };
}

export default function App() {
  const initial = useMemo(() => loadSavedProgress(), []);

  const [level, setLevel] = useState<number>(initial.level);
  const [coins, setCoins] = useState<number>(initial.coins);
  const [lives, setLives] = useState<number>(initial.lives);
  const [clearedTotal, setClearedTotal] = useState<number>(initial.clearedTotal);
  const [dailyBonusDate, setDailyBonusDate] = useState<string>(initial.dailyBonusDate);
  const [dailyBonusEarned, setDailyBonusEarned] = useState<number>(initial.dailyBonusEarned);

  const [pins, setPins] = useState<Pin[]>(() => generateLevelPins(initial.level));
  const [remainingCount, setRemainingCount] = useState<number>(() => pins.length);
  const [totalPinsInLevel, setTotalPinsInLevel] = useState<number>(() => pins.length);

  const [gamePhase, setGamePhase] = useState<GamePhase>(
    initial.lives <= 0 ? 'GAME_OVER' : 'PLAYING'
  );
  const [rewardModal, setRewardModal] = useState<RewardMode>(null);
  const [adLoading, setAdLoading] = useState<boolean>(false);
  const [hintPinId, setHintPinId] = useState<number | null>(null);
  const [muted, setMuted] = useState<boolean>(false);
  const [copiedHtml, setCopiedHtml] = useState<boolean>(false);
  const [copiedWorkflow, setCopiedWorkflow] = useState<boolean>(false);
  const [exportTab, setExportTab] = useState<'STARTIO' | 'GAMEMONETIZE'>('STARTIO');
  const [startIoAppId, setStartIoAppId] = useState<string>('');
  const [startIoTesting, setStartIoTesting] = useState<boolean>(true);
  const [zippingAndroid, setZippingAndroid] = useState<boolean>(false);
  const [gmGameId, setGmGameId] = useState<string>('72sgpz3vna24fkylq72330w2t1r5nl4o');
  const [zipping, setZipping] = useState<boolean>(false);
  const [shaking, setShaking] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<{ text: string; tone: 'error' | 'success' | 'info' } | null>(
    null
  );
  const [impactEvent, setImpactEvent] = useState<{ x: number; y: number; key: number } | null>(null);

  const pinsRef = useRef<Pin[]>(pins);
  const comboRef = useRef<number>(0);
  const levelEarnedRef = useRef<number>(0);
  const feedbackTimerRef = useRef<number | null>(null);

  const levelConfig = useMemo(() => getLevelConfig(level), [level]);

  // Keep ref synced when a new level array is created
  const initBoardForLevel = useCallback((targetLevel: number) => {
    const newPins = generateLevelPins(targetLevel);
    pinsRef.current = newPins;
    setPins(newPins);
    setTotalPinsInLevel(newPins.length);
    setRemainingCount(newPins.length);
    setHintPinId(null);
    comboRef.current = 0;
  }, []);

  // Initialize native Start.io when running inside Capacitor Android
  useEffect(() => {
    void initStartIo();
  }, []);

  // Sync initial remaining counts cleanly
  useEffect(() => {
    pinsRef.current = pins;
    setTotalPinsInLevel(pins.length);
    setRemainingCount(pins.filter((p) => p.status !== 'removed').length);
  }, [pins]);

  // Persist progress
  useEffect(() => {
    try {
      const payload: SavedProgress = {
        level,
        coins,
        lives,
        clearedTotal,
        dailyBonusDate,
        dailyBonusEarned,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    } catch {
      // Ignore storage errors
    }
  }, [level, coins, lives, clearedTotal, dailyBonusDate, dailyBonusEarned]);

  const showFeedback = useCallback(
    (text: string, tone: 'error' | 'success' | 'info') => {
      if (feedbackTimerRef.current) {
        window.clearTimeout(feedbackTimerRef.current);
      }
      setFeedback({ text, tone });
      feedbackTimerRef.current = window.setTimeout(() => {
        setFeedback(null);
      }, 2200);
    },
    []
  );

  // Reward / Simulated Ad countdown timer
  useEffect(() => {
    if (!rewardModal) return;
    const interval = window.setInterval(() => {
      setRewardModal((prev) => {
        if (!prev) return null;
        const nextElapsed = prev.elapsed + 0.1;
        if (nextElapsed >= prev.totalSec) {
          return { ...prev, elapsed: prev.totalSec };
        }
        return { ...prev, elapsed: nextElapsed };
      });
    }, 100);
    return () => window.clearInterval(interval);
  }, [Boolean(rewardModal)]);

  // Claim reward as soon as timer completes
  const claimReward = useCallback(() => {
    if (!rewardModal || rewardModal.elapsed < rewardModal.totalSec) return;
    if (rewardModal.type === 'AD_LIVES') {
      setLives((l) => Math.min(MAX_LIVES, l + AD_LIFE_REWARD));
      setGamePhase((p) => (p === 'GAME_OVER' ? 'PLAYING' : p));
      sound.playReward();
      showFeedback(`+${AD_LIFE_REWARD} vies récupérées !`, 'success');
    } else {
      const today = getTodayKey();
      const earnedToday = dailyBonusDate === today ? dailyBonusEarned : 0;
      const remaining = Math.max(0, DAILY_COIN_LIMIT - earnedToday);
      const granted = Math.min(rewardModal.amount ?? COIN_TASK_REWARD, remaining);
      if (granted > 0) {
        setDailyBonusDate(today);
        setDailyBonusEarned(earnedToday + granted);
        setCoins((c) => c + granted);
        sound.playReward();
        showFeedback(`+${granted} pièces gagnées !`, 'success');
      } else {
        showFeedback('Limite quotidienne de 50 pièces atteinte', 'info');
      }
    }
    setRewardModal(null);
  }, [rewardModal, dailyBonusDate, dailyBonusEarned, showFeedback]);

  const handlePinTap = useCallback(
    (pinId: number) => {
      if (gamePhase !== 'PLAYING' || rewardModal !== null) return;
      const list = pinsRef.current;
      const tapped = list.find((p) => p.id === pinId);
      if (!tapped || tapped.status !== 'idle') return;

      const block = findBlockingPin(tapped, list);
      if (!block) {
        // Free to slide out!
        tapped.status = 'exiting';
        comboRef.current += 1;
        sound.playSlide(comboRef.current);
        if (hintPinId === pinId) setHintPinId(null);
      } else {
        // Collision! Bounce back and lose 1 life
        comboRef.current = 0;
        tapped.status = 'bouncing';
        tapped.bounceProgress = 0;
        tapped.bounceMax = Math.max(10, Math.min(28, block.hitDistance));
        tapped.flashTimer = 0.36;

        const blocker = list.find((p) => p.id === block.blockedById);
        if (blocker) blocker.flashTimer = 0.36;

        setImpactEvent({
          x: block.impactPoint.x,
          y: block.impactPoint.y,
          key: Date.now() + Math.random(),
        });

        setShaking(true);
        window.setTimeout(() => setShaking(false), 290);
        sound.playBlock();

        setLives((prev) => {
          const next = Math.max(0, prev - 1);
          if (next === 0) {
            sound.playGameOver();
            setGamePhase('GAME_OVER');
          } else {
            showFeedback('Quille bloquée ! -1 vie', 'error');
          }
          return next;
        });
      }
    },
    [gamePhase, rewardModal, hintPinId, showFeedback]
  );

  const handleAnimationTick = useCallback(
    (dt: number) => {
      const list = pinsRef.current;
      let removedThisFrame = false;

      for (const pin of list) {
        if (pin.flashTimer > 0) {
          pin.flashTimer = Math.max(0, pin.flashTimer - dt);
        }

        if (pin.status === 'exiting') {
          pin.offset += 820 * dt;
          if (pin.offset > 470) {
            pin.status = 'removed';
            removedThisFrame = true;
          }
        } else if (pin.status === 'bouncing') {
          pin.bounceProgress += dt / 0.24;
          if (pin.bounceProgress >= 1) {
            pin.bounceProgress = 0;
            pin.offset = 0;
            pin.status = 'idle';
          } else {
            pin.offset = Math.sin(pin.bounceProgress * Math.PI) * pin.bounceMax;
          }
        }
      }

      if (removedThisFrame) {
        const left = list.filter((p) => p.status !== 'removed').length;
        setRemainingCount(left);
        setClearedTotal((t) => t + 1);

        if (left === 0 && gamePhase === 'PLAYING') {
          const reward = getLevelConfig(level).coinReward;
          levelEarnedRef.current = reward;
          setCoins((c) => c + reward);
          sound.playLevelWin();
          setGamePhase('LEVEL_CLEAR');
        }
      }
    },
    [gamePhase, level]
  );

  const handleNextLevel = () => {
    const nextLvl = level + 1;
    if (isNativeMobile() && level % 3 === 0) {
      void showNativeInterstitial();
    }
    setLevel(nextLvl);
    initBoardForLevel(nextLvl);
    setGamePhase('PLAYING');
    setFeedback(null);
  };

  const handleBuyLife = () => {
    if (coins < LIFE_COST || lives >= MAX_LIVES) return;
    setCoins((c) => c - LIFE_COST);
    setLives((l) => Math.min(MAX_LIVES, l + 1));
    if (gamePhase === 'GAME_OVER') {
      setGamePhase('PLAYING');
    }
    sound.playReward();
    showFeedback('+1 vie achetée !', 'success');
  };

  const handleWatchAd = async () => {
    if (lives >= MAX_LIVES || rewardModal !== null || adLoading) return;
    if (isNativeMobile()) {
      setAdLoading(true);
      const outcome = await showNativeRewardedAd();
      setAdLoading(false);
      if (outcome === 'REWARDED') {
        setLives((l) => Math.min(MAX_LIVES, l + AD_LIFE_REWARD));
        setGamePhase((p) => (p === 'GAME_OVER' ? 'PLAYING' : p));
        sound.playReward();
        showFeedback(`+${AD_LIFE_REWARD} vies récupérées !`, 'success');
        return;
      }
      if (outcome === 'DISMISSED') {
        showFeedback('Regardez la pub jusqu’au bout pour gagner +2 vies', 'info');
        return;
      }
      if (outcome !== 'UNCONFIGURED') {
        showFeedback('Publicité indisponible pour le moment', 'error');
        return;
      }
    }
    setRewardModal({ type: 'AD_LIVES', totalSec: AD_DURATION_SEC, elapsed: 0 });
  };

  const todayKey = getTodayKey();
  const effectiveDailyEarned = dailyBonusDate === todayKey ? dailyBonusEarned : 0;
  const dailyBonusRemaining = Math.max(0, DAILY_COIN_LIMIT - effectiveDailyEarned);
  const nextBonusAmount = Math.min(COIN_TASK_REWARD, dailyBonusRemaining);

  const handleEarnCoins = async () => {
    if (rewardModal !== null || adLoading || dailyBonusRemaining <= 0) return;
    if (dailyBonusDate !== todayKey) {
      setDailyBonusDate(todayKey);
      setDailyBonusEarned(0);
    }
    if (isNativeMobile()) {
      setAdLoading(true);
      const outcome = await showNativeRewardedAd();
      setAdLoading(false);
      if (outcome === 'REWARDED') {
        const currentToday = getTodayKey();
        const earned = dailyBonusDate === currentToday ? dailyBonusEarned : 0;
        const granted = Math.min(COIN_TASK_REWARD, Math.max(0, DAILY_COIN_LIMIT - earned));
        if (granted > 0) {
          setDailyBonusDate(currentToday);
          setDailyBonusEarned(earned + granted);
          setCoins((c) => c + granted);
          sound.playReward();
          showFeedback(`+${granted} pièces gagnées !`, 'success');
        }
        return;
      }
      if (outcome === 'DISMISSED') {
        showFeedback('Regardez la pub jusqu’au bout pour gagner les pièces', 'info');
        return;
      }
      if (outcome !== 'UNCONFIGURED') {
        showFeedback('Publicité indisponible pour le moment', 'error');
        return;
      }
    }
    setRewardModal({
      type: 'EARN_COINS',
      totalSec: COIN_TASK_DURATION_SEC,
      elapsed: 0,
      amount: nextBonusAmount,
    });
  };

  const handleUseHint = () => {
    if (gamePhase !== 'PLAYING' || coins < HINT_COST) return;
    const freeIds = getFreePinIds(pinsRef.current);
    if (freeIds.length === 0) return;
    setCoins((c) => c - HINT_COST);
    const chosen = freeIds[0];
    setHintPinId(chosen);
    showFeedback('Quille libre mise en évidence', 'info');
  };

  const handleRestartLevel = () => {
    if (gamePhase === 'GAME_OVER') return;
    initBoardForLevel(level);
    showFeedback('Plateau réinitialisé', 'info');
  };

  const handleNewGame = () => {
    setLevel(1);
    setCoins(60);
    setLives(MAX_LIVES);
    setClearedTotal(0);
    initBoardForLevel(1);
    setGamePhase('PLAYING');
    setFeedback(null);
  };

  const toggleMute = () => {
    sound.muted = !muted;
    setMuted(!muted);
  };

  const buildExportHtml = useCallback((rawId: string) => {
    const cleanId = rawId.trim().replace(/[^a-zA-Z0-9_-]/g, '') || '72sgpz3vna24fkylq72330w2t1r5nl4o';
    return standaloneHtml.replace(
      'gameId: "72sgpz3vna24fkylq72330w2t1r5nl4o"',
      `gameId: "${cleanId}"`
    );
  }, []);

  const handleDownloadAndroidProjectZip = async () => {
    if (zippingAndroid) return;
    setZippingAndroid(true);
    try {
      const response = await fetch('/pin-untangle-android-project.zip');
      if (!response.ok) {
        throw new Error('Archive introuvable');
      }
      const arrayBuffer = await response.arrayBuffer();
      const zip = await JSZip.loadAsync(arrayBuffer);

      const cleanId = startIoAppId.trim().replace(/[^a-zA-Z0-9_-]/g, '');
      if (cleanId) {
        const stringsFile = zip.file('android/app/src/main/res/values/strings.xml');
        if (stringsFile) {
          const xml = await stringsFile.async('string');
          zip.file(
            'android/app/src/main/res/values/strings.xml',
            xml.replace(
              /<string name="startio_app_id">[^<]*<\/string>/,
              `<string name="startio_app_id">${cleanId}</string>`
            )
          );
        }
      }

      const workflowFile = zip.file('.github/workflows/build-android.yml');
      if (workflowFile) {
        const yml = await workflowFile.async('string');
        zip.file(
          '.github/workflows/build-android.yml',
          yml.replace(
            "VITE_STARTIO_TESTING: ${{ vars.VITE_STARTIO_TESTING || 'true' }}",
            `VITE_STARTIO_TESTING: \${{ vars.VITE_STARTIO_TESTING || '${startIoTesting ? 'true' : 'false'}' }}`
          )
        );
      }

      const blob = await zip.generateAsync({
        type: 'blob',
        compression: 'DEFLATE',
        compressionOptions: { level: 6 },
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'pin-untangle-android-startio.zip';
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      showFeedback('Projet Android + Start.io (.zip) téléchargé !', 'success');
    } catch {
      showFeedback('Impossible de télécharger le projet Android', 'error');
    } finally {
      setZippingAndroid(false);
    }
  };

  const handleCopyWorkflow = async () => {
    const cleanYml = workflowTemplate.replace(
      "VITE_STARTIO_TESTING: ${{ vars.VITE_STARTIO_TESTING || 'true' }}",
      `VITE_STARTIO_TESTING: \${{ vars.VITE_STARTIO_TESTING || '${startIoTesting ? 'true' : 'false'}' }}`
    );
    try {
      await navigator.clipboard.writeText(cleanYml);
      setCopiedWorkflow(true);
      showFeedback('Workflow GitHub copié !', 'success');
      window.setTimeout(() => setCopiedWorkflow(false), 2400);
    } catch {
      showFeedback('Copiez le workflow depuis la discussion', 'info');
    }
  };

  const handleDownloadGameMonetizeZip = async () => {
    if (zipping) return;
    setZipping(true);
    try {
      const zip = new JSZip();
      zip.file('index.html', buildExportHtml(gmGameId));
      const blob = await zip.generateAsync({
        type: 'blob',
        compression: 'DEFLATE',
        compressionOptions: { level: 6 },
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'pin-untangle-gamemonetize.zip';
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      showFeedback('Archive .zip GameMonetize téléchargée !', 'success');
    } catch {
      showFeedback('Impossible de créer le fichier .zip', 'error');
    } finally {
      setZipping(false);
    }
  };

  const handleDownloadHtml = () => {
    const blob = new Blob([buildExportHtml(gmGameId)], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'index.html';
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    showFeedback('Fichier index.html téléchargé !', 'success');
  };

  const handleCopyHtml = async () => {
    try {
      await navigator.clipboard.writeText(buildExportHtml(gmGameId));
      setCopiedHtml(true);
      showFeedback('Code HTML copié !', 'success');
      window.setTimeout(() => setCopiedHtml(false), 2200);
    } catch {
      showFeedback('Utilisez le bouton Télécharger index.html', 'info');
    }
  };

  const adSecondsLeft = rewardModal
    ? Math.max(0, Math.ceil(rewardModal.totalSec - rewardModal.elapsed))
    : 0;
  const rewardReady = rewardModal ? rewardModal.elapsed >= rewardModal.totalSec : false;
  const rewardPercent = rewardModal
    ? Math.min(100, Math.round((rewardModal.elapsed / rewardModal.totalSec) * 100))
    : 0;

  return (
    <div className="min-h-screen bg-[#F2F4F7] text-[#0F172A] flex flex-col">
      {/* Compact Sticky Top Stats Header */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-5xl mx-auto px-4 h-14 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 shrink-0">
            <span className="text-base sm:text-lg font-extrabold tracking-tight text-slate-900 whitespace-nowrap">
              Pin Untangle
            </span>
          </div>

          {/* Stats Counters (Tabular numerals, clean dividers, zero pills) */}
          <div className="flex items-center gap-4 sm:gap-6">
            <div className="flex items-center gap-1.5" title="Niveau actuel">
              <span className="text-xs font-semibold text-slate-500 hidden sm:inline">Niveau</span>
              <span className="text-xs font-semibold text-slate-500 sm:hidden">Niv.</span>
              <span className="font-mono-num text-sm sm:text-base font-bold text-slate-900">
                {level}
              </span>
            </div>

            <div className="h-4 w-px bg-slate-200" aria-hidden="true" />

            <div className="flex items-center gap-1.5" title="Pièces">
              <Coins className="w-4 h-4 text-amber-600 shrink-0" aria-hidden="true" />
              <span className="font-mono-num text-sm sm:text-base font-bold text-slate-900">
                {coins}
              </span>
            </div>

            <div className="h-4 w-px bg-slate-200" aria-hidden="true" />

            <div className="flex items-center gap-1.5" title="Vies restantes">
              <Heart
                className={`w-4 h-4 shrink-0 ${
                  lives > 0 ? 'text-rose-600 fill-rose-600' : 'text-slate-300'
                }`}
                aria-hidden="true"
              />
              <span
                className={`font-mono-num text-sm sm:text-base font-bold ${
                  lives <= 1 ? 'text-rose-600' : 'text-slate-900'
                }`}
              >
                {lives}/{MAX_LIVES}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              onClick={toggleMute}
              aria-label={muted ? 'Activer le son' : 'Couper le son'}
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
            >
              {muted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area: Vertical Mobile Playfield + Desktop Companion Panel */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 pt-4 pb-20 sm:py-6 lg:pb-8 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left/Center Column: Vertical Mobile Puzzle Playfield */}
        <section className="lg:col-span-7 flex flex-col items-center w-full">
          {/* Level Metadata Line & Quick Board Tools */}
          <div className="w-full max-w-[380px] flex items-center justify-between gap-2 mb-3">
            <div className="flex items-center gap-2 text-xs sm:text-sm font-medium text-slate-600">
              <span>
                Quilles : <strong className="font-mono-num text-slate-900">{remainingCount}/{totalPinsInLevel}</strong>
              </span>
              <span aria-hidden="true">·</span>
              <span>
                Blocage : <strong className="text-slate-900">{levelConfig.blockingRiskLabel}</strong>
              </span>
            </div>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={handleUseHint}
                disabled={gamePhase !== 'PLAYING' || coins < HINT_COST}
                title={`Indice (${HINT_COST} pièces)`}
                className="min-h-[38px] px-2.5 rounded-lg text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1 transition-colors cursor-pointer whitespace-nowrap"
              >
                <Lightbulb className="w-3.5 h-3.5" />
                <span>Indice ({HINT_COST})</span>
              </button>
              <button
                type="button"
                onClick={handleRestartLevel}
                disabled={gamePhase !== 'PLAYING'}
                title="Réinitialiser la disposition"
                aria-label="Réinitialiser la disposition"
                className="min-h-[38px] min-w-[38px] rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-200/70 disabled:opacity-40 flex items-center justify-center transition-colors cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Interactive Board Container */}
          <div className="relative w-full max-w-[380px]">
            <PinBoard
              pins={pins}
              hintPinId={hintPinId}
              disabled={gamePhase !== 'PLAYING' || rewardModal !== null}
              shaking={shaking}
              onPinTap={handlePinTap}
              onAnimationTick={handleAnimationTick}
              impactEvent={impactEvent}
            />

            {/* Ephemeral Tactile Toast Feedback inside Board Top */}
            {feedback && (
              <div
                role="status"
                aria-live="polite"
                className={`pointer-events-none absolute top-3 left-1/2 -translate-x-1/2 px-3.5 py-2 rounded-xl text-xs font-bold shadow-md whitespace-nowrap transition-opacity ${
                  feedback.tone === 'error'
                    ? 'bg-rose-600 text-white'
                    : feedback.tone === 'success'
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-900 text-white'
                }`}
              >
                {feedback.text}
              </div>
            )}

            {/* Level Victory Overlay */}
            {gamePhase === 'LEVEL_CLEAR' && (
              <div className="absolute inset-0 z-20 bg-slate-900/55 backdrop-blur-xs rounded-3xl flex items-center justify-center p-5">
                <div className="w-full max-w-[300px] bg-white rounded-2xl p-6 text-center shadow-xl border border-slate-200">
                  <p className="text-xs font-semibold text-emerald-700 mb-1">
                    Niveau {level} terminé
                  </p>
                  <h2 className="text-xl font-extrabold text-slate-900 mb-2">
                    Plateau démêlé !
                  </h2>
                  <p className="text-sm text-slate-600 mb-5">
                    Vous gagnez{' '}
                    <strong className="font-mono-num text-amber-600">
                      +{levelEarnedRef.current} pièces
                    </strong>{' '}
                    pour ce niveau.
                  </p>
                  <button
                    type="button"
                    onClick={handleNextLevel}
                    className="w-full min-h-[48px] px-5 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-[0.98] text-white font-bold text-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>Niveau suivant</span>
                  </button>
                </div>
              </div>
            )}

            {/* Game Over Overlay */}
            {gamePhase === 'GAME_OVER' && (
              <div className="absolute inset-0 z-20 bg-slate-900/65 backdrop-blur-xs rounded-3xl flex items-center justify-center p-4">
                <div className="w-full max-w-[320px] bg-white rounded-2xl p-5 sm:p-6 text-center shadow-2xl border border-slate-200">
                  <div className="w-11 h-11 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto mb-3">
                    <ShieldAlert className="w-6 h-6" />
                  </div>
                  <h2 className="text-xl font-extrabold text-slate-900 mb-1">Game Over</h2>
                  <p className="text-sm text-slate-600 mb-4">
                    Plus de vies au niveau <strong className="font-mono-num text-slate-900">{level}</strong>.
                    Utilisez une option de secours pour continuer :
                  </p>

                  <div className="flex flex-col gap-2.5">
                    <button
                      type="button"
                      onClick={handleBuyLife}
                      disabled={coins < LIFE_COST}
                      className="w-full min-h-[46px] px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:bg-slate-200 disabled:text-slate-500 text-white text-sm font-bold flex items-center justify-between transition-colors cursor-pointer disabled:cursor-not-allowed"
                    >
                      <span className="flex items-center gap-2">
                        <Heart className="w-4 h-4 text-rose-400 fill-rose-400" />
                        <span>Racheter 1 vie</span>
                      </span>
                      <span className="font-mono-num text-xs">
                        {LIFE_COST} pièces
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={handleWatchAd}
                      className="w-full min-h-[46px] px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold flex items-center justify-between transition-colors cursor-pointer"
                    >
                      <span className="flex items-center gap-2">
                        <Tv className="w-4 h-4" />
                        <span>Pub secours (+{AD_LIFE_REWARD} vies)</span>
                      </span>
                      <span className="text-xs font-semibold">
                        Illimité
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={handleEarnCoins}
                      disabled={dailyBonusRemaining <= 0}
                      className="w-full min-h-[46px] px-4 py-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 disabled:bg-slate-200 disabled:text-slate-500 border border-amber-200 disabled:border-transparent text-amber-900 text-sm font-bold flex items-center justify-between transition-colors cursor-pointer disabled:cursor-not-allowed"
                    >
                      <span className="flex items-center gap-2">
                        <Coins className="w-4 h-4 text-amber-600" />
                        <span>Gagner des pièces</span>
                      </span>
                      <span className="font-mono-num text-xs text-amber-700">
                        {dailyBonusRemaining > 0
                          ? `+${nextBonusAmount} (${dailyBonusRemaining}/${DAILY_COIN_LIMIT})`
                          : '0/50 auj.'}
                      </span>
                    </button>

                    <div className="pt-2 mt-1 border-t border-slate-100">
                      <button
                        type="button"
                        onClick={handleNewGame}
                        className="w-full min-h-[44px] px-4 py-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 text-sm font-semibold transition-colors cursor-pointer"
                      >
                        Recommencer au niveau 1
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Mobile Thumb-Zone Action Strip (visible below board on mobile/tablet) */}
          <div className="w-full max-w-[380px] mt-4 grid grid-cols-3 gap-2 lg:hidden">
            <button
              type="button"
              onClick={handleBuyLife}
              disabled={coins < LIFE_COST || lives >= MAX_LIVES}
              className="min-h-[54px] px-2 py-2 rounded-2xl bg-white border border-slate-200 hover:border-slate-300 disabled:opacity-45 flex flex-col items-center justify-center gap-0.5 text-center transition-colors cursor-pointer disabled:cursor-not-allowed"
            >
              <span className="text-xs font-bold text-slate-900 flex items-center gap-1 whitespace-nowrap">
                <Heart className="w-3.5 h-3.5 text-rose-600 fill-rose-600" />
                <span>+1 Vie</span>
              </span>
              <span className="font-mono-num text-[11px] font-medium text-slate-500">
                {LIFE_COST} pièces
              </span>
            </button>

            <button
              type="button"
              onClick={handleWatchAd}
              disabled={lives >= MAX_LIVES}
              className="min-h-[54px] px-2 py-2 rounded-2xl bg-white border border-slate-200 hover:border-slate-300 disabled:opacity-45 flex flex-col items-center justify-center gap-0.5 text-center transition-colors cursor-pointer disabled:cursor-not-allowed"
            >
              <span className="text-xs font-bold text-blue-700 flex items-center gap-1 whitespace-nowrap">
                <Tv className="w-3.5 h-3.5" />
                <span>Pub +{AD_LIFE_REWARD}</span>
              </span>
              <span className="text-[11px] font-medium text-slate-500">
                Illimité
              </span>
            </button>

            <button
              type="button"
              onClick={handleEarnCoins}
              disabled={dailyBonusRemaining <= 0}
              className="min-h-[54px] px-2 py-2 rounded-2xl bg-white border border-slate-200 hover:border-amber-300 disabled:opacity-45 flex flex-col items-center justify-center gap-0.5 text-center transition-colors cursor-pointer disabled:cursor-not-allowed"
            >
              <span className="text-xs font-bold text-amber-700 flex items-center gap-1 whitespace-nowrap">
                <Coins className="w-3.5 h-3.5 text-amber-600" />
                <span>
                  {dailyBonusRemaining > 0 ? `+${nextBonusAmount} Pièces` : 'Bonus max'}
                </span>
              </span>
              <span className="font-mono-num text-[11px] font-medium text-slate-500 whitespace-nowrap">
                {dailyBonusRemaining}/{DAILY_COIN_LIMIT} auj.
              </span>
            </button>
          </div>
        </section>

        {/* Right Column (Desktop Companion & Recovery Hub, also accessible below on mobile) */}
        <aside className="lg:col-span-5 flex flex-col gap-5 w-full max-w-[380px] lg:max-w-none mx-auto">
          {/* Recovery & Economy Panel (visible on desktop lg+, since mobile has thumb strip above) */}
          <div className="hidden lg:block bg-white rounded-2xl border border-slate-200 p-6">
            <h2 className="text-base font-bold text-slate-900 mb-1">
              Options de secours & Boutique
            </h2>
            <p className="text-sm text-slate-600 mb-4">
              Récupérez des vies en cas de blocage ou accumulez des pièces à tout moment.
            </p>

            <div className="flex flex-col gap-3">
              <button
                type="button"
                onClick={handleBuyLife}
                disabled={coins < LIFE_COST || lives >= MAX_LIVES}
                className="w-full min-h-[48px] px-4 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:bg-slate-100 disabled:text-slate-400 text-white text-sm font-bold flex items-center justify-between transition-colors cursor-pointer disabled:cursor-not-allowed"
              >
                <span className="flex items-center gap-2.5">
                  <Heart className="w-4 h-4 text-rose-400 fill-rose-400" />
                  <span>Racheter 1 vie</span>
                </span>
                <span className="font-mono-num text-xs">
                  {lives >= MAX_LIVES ? 'Vies max' : `${LIFE_COST} pièces`}
                </span>
              </button>

              <button
                type="button"
                onClick={handleWatchAd}
                disabled={lives >= MAX_LIVES}
                className="w-full min-h-[48px] px-4 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:bg-slate-100 disabled:text-slate-400 text-white text-sm font-bold flex items-center justify-between transition-colors cursor-pointer disabled:cursor-not-allowed"
              >
                <span className="flex items-center gap-2.5">
                  <Tv className="w-4 h-4" />
                  <span>Regarder une pub (+{AD_LIFE_REWARD} vies)</span>
                </span>
                <span className="text-xs font-semibold">
                  {lives >= MAX_LIVES ? 'Vies max' : 'Illimité'}
                </span>
              </button>

              <button
                type="button"
                onClick={handleEarnCoins}
                disabled={dailyBonusRemaining <= 0}
                className="w-full min-h-[48px] px-4 py-3 rounded-xl bg-amber-50 hover:bg-amber-100 disabled:bg-slate-100 disabled:text-slate-400 border border-amber-200 disabled:border-transparent text-amber-900 text-sm font-bold flex items-center justify-between transition-colors cursor-pointer disabled:cursor-not-allowed"
              >
                <span className="flex items-center gap-2.5">
                  <Coins className="w-4 h-4 text-amber-600" />
                  <span>Gagner des pièces</span>
                </span>
                <span className="font-mono-num text-xs text-amber-700">
                  {dailyBonusRemaining > 0
                    ? `+${nextBonusAmount} · Reste ${dailyBonusRemaining}/${DAILY_COIN_LIMIT}`
                    : 'Limite 50/50 atteinte'}
                </span>
              </button>
            </div>
          </div>

          {/* Rules & Progression Panel */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6">
            <div className="flex items-center gap-2 mb-3">
              <HelpCircle className="w-4 h-4 text-slate-500" />
              <h2 className="text-base font-bold text-slate-900">Comment jouer</h2>
            </div>

            <ol className="space-y-2.5 text-sm text-slate-600 leading-relaxed">
              <li>
                <strong className="text-slate-900">1. Observez la flèche :</strong> chaque quille indique sa direction de sortie sur sa tête.
              </li>
              <li>
                <strong className="text-slate-900">2. Touchez les quilles libres :</strong> si aucune autre quille ne coupe sa trajectoire, elle se détache proprement.
              </li>
              <li>
                <strong className="text-slate-900">3. Évitez les blocages :</strong> toucher une quille bloquée provoque une collision et vous fait perdre 1 vie.
              </li>
            </ol>

            <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span>
                Récompense niveau {level} : <strong className="font-mono-num text-slate-900">+{levelConfig.coinReward} pièces</strong>
              </span>
              <span>
                Quilles retirées : <strong className="font-mono-num text-slate-900">{clearedTotal}</strong>
              </span>
            </div>

            <div className="mt-4 pt-4 border-t border-slate-100 flex flex-col gap-3">
              {/* Segmented Export Target Switch */}
              <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-xl">
                <button
                  type="button"
                  onClick={() => setExportTab('STARTIO')}
                  className={`min-h-[40px] px-2.5 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer whitespace-nowrap ${
                    exportTab === 'STARTIO'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  APK Start.io (GitHub)
                </button>
                <button
                  type="button"
                  onClick={() => setExportTab('GAMEMONETIZE')}
                  className={`min-h-[40px] px-2.5 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer whitespace-nowrap ${
                    exportTab === 'GAMEMONETIZE'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Web (GameMonetize)
                </button>
              </div>

              {exportTab === 'STARTIO' ? (
                <div className="flex flex-col gap-3">
                  <div className="flex flex-col gap-1.5">
                    <label
                      htmlFor="startio-app-id"
                      className="text-xs font-semibold text-slate-700"
                    >
                      App ID Start.io (portal.start.io)
                    </label>
                    <input
                      id="startio-app-id"
                      type="text"
                      value={startIoAppId}
                      onChange={(e) => setStartIoAppId(e.target.value)}
                      placeholder="Ex : 204653121 (optionnel si mis sur GitHub)"
                      spellCheck={false}
                      autoComplete="off"
                      className="w-full min-h-[42px] px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-blue-500 focus:outline-none font-mono text-xs text-slate-800"
                    />
                  </div>

                  <div className="flex items-center justify-between gap-2 text-xs">
                    <span className="text-slate-600 font-medium">Mode des pubs Start.io</span>
                    <button
                      type="button"
                      onClick={() => setStartIoTesting((v) => !v)}
                      className="min-h-[38px] px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 font-semibold text-slate-800 transition-colors cursor-pointer whitespace-nowrap"
                    >
                      {startIoTesting ? 'Test (sans risque)' : 'Pubs réelles'}
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={handleDownloadAndroidProjectZip}
                    disabled={zippingAndroid}
                    className="w-full min-h-[46px] px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-[0.99] disabled:opacity-60 text-white text-sm font-bold flex items-center justify-center gap-2 transition-all cursor-pointer whitespace-nowrap"
                  >
                    <Smartphone className="w-4 h-4 shrink-0" />
                    <span>
                      {zippingAndroid
                        ? 'Préparation du projet…'
                        : 'Télécharger projet Android (.zip)'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={handleCopyWorkflow}
                    className="w-full min-h-[42px] px-3 py-2 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    {copiedWorkflow ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    ) : (
                      <Copy className="w-3.5 h-3.5 shrink-0" />
                    )}
                    <span>
                      {copiedWorkflow
                        ? 'Workflow copié !'
                        : 'Copier workflow (.github/workflows/build-android.yml)'}
                    </span>
                  </button>

                  <p className="text-xs text-slate-500 leading-relaxed">
                    Sans Codespaces : envoyez ce .zip sur GitHub (Add file → Upload files), puis créez le fichier workflow collé ci-dessus.
                  </p>
                </div>
              ) : (
                <div className="flex flex-col gap-3">
                  <div className="flex flex-col gap-1.5">
                    <label
                      htmlFor="gm-game-id"
                      className="text-xs font-semibold text-slate-700"
                    >
                      ID GameMonetize (SDK intégré)
                    </label>
                    <input
                      id="gm-game-id"
                      type="text"
                      value={gmGameId}
                      onChange={(e) => setGmGameId(e.target.value)}
                      spellCheck={false}
                      autoComplete="off"
                      className="w-full min-h-[42px] px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-blue-500 focus:outline-none font-mono text-xs text-slate-800"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={handleDownloadGameMonetizeZip}
                    disabled={zipping}
                    className="w-full min-h-[46px] px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] disabled:opacity-60 text-white text-sm font-bold flex items-center justify-center gap-2 transition-all cursor-pointer whitespace-nowrap"
                  >
                    <FolderArchive className="w-4 h-4 shrink-0" />
                    <span>
                      {zipping ? 'Création du .zip…' : 'Télécharger .zip GameMonetize'}
                    </span>
                  </button>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={handleDownloadHtml}
                      className="min-h-[42px] px-3 py-2 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Télécharger index.html</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleCopyHtml}
                      className="min-h-[42px] px-3 py-2 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
                    >
                      {copiedHtml ? (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                      <span>{copiedHtml ? 'Copié !' : 'Copier HTML'}</span>
                    </button>
                  </div>
                </div>
              )}

              <div className="flex justify-end pt-1 border-t border-slate-100">
                <button
                  type="button"
                  onClick={handleNewGame}
                  className="min-h-[42px] px-3 py-2 rounded-xl text-xs font-semibold text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer whitespace-nowrap"
                >
                  Nouvelle partie
                </button>
              </div>
            </div>
          </div>
        </aside>
      </main>

      {/* Simulated Ad / Coin Reward Modal */}
      {rewardModal && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="reward-modal-title"
        >
          <div className="w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 text-center">
            <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-3">
              {rewardModal.type === 'AD_LIVES' ? (
                <Tv className="w-6 h-6" />
              ) : (
                <Coins className="w-6 h-6 text-amber-600" />
              )}
            </div>

            <h3 id="reward-modal-title" className="text-lg font-extrabold text-slate-900 mb-1">
              {rewardModal.type === 'AD_LIVES'
                ? 'Récupération de vies en cours'
                : 'Bonus de pièces en cours'}
            </h3>

            <p className="text-sm text-slate-600 mb-5">
              {rewardReady
                ? rewardModal.type === 'AD_LIVES'
                  ? `Prêt ! Vous pouvez récupérer +${AD_LIFE_REWARD} vies.`
                  : `Votre coffre de +${rewardModal.amount ?? COIN_TASK_REWARD} pièces est prêt !`
                : `Pause de soutien : patientez ${adSecondsLeft} seconde${adSecondsLeft > 1 ? 's' : ''} pour débloquer votre récompense.`}
            </p>

            {/* Progress bar */}
            <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden mb-5">
              <div
                className={`h-full transition-all duration-100 ${
                  rewardModal.type === 'AD_LIVES' ? 'bg-blue-600' : 'bg-amber-500'
                }`}
                style={{ width: `${rewardPercent}%` }}
              />
            </div>

            <div className="flex flex-col gap-2">
              <button
                type="button"
                disabled={!rewardReady}
                onClick={claimReward}
                className="w-full min-h-[48px] px-4 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-200 disabled:text-slate-500 text-white font-bold text-sm transition-colors cursor-pointer disabled:cursor-not-allowed"
              >
                {rewardReady
                  ? rewardModal.type === 'AD_LIVES'
                    ? `Récupérer +${AD_LIFE_REWARD} vies`
                    : `Encaisser +${rewardModal.amount ?? COIN_TASK_REWARD} pièces`
                  : `Déblocage dans ${adSecondsLeft}s…`}
              </button>

              {!rewardReady && (
                <button
                  type="button"
                  onClick={() => setRewardModal(null)}
                  className="w-full min-h-[44px] px-4 py-2 rounded-xl text-xs font-semibold text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors cursor-pointer"
                >
                  Annuler (aucune récompense)
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
