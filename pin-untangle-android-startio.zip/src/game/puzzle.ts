export interface PinColorTheme {
  name: string;
  body: string;
  head: string;
  border: string;
  highlight: string;
}

export const PIN_PALETTE: PinColorTheme[] = [
  { name: 'Cobalt', body: '#2563EB', head: '#1D4ED8', border: '#1E40AF', highlight: '#93C5FD' },
  { name: 'Corail', body: '#E11D48', head: '#BE123C', border: '#9F1239', highlight: '#FDA4AF' },
  { name: 'Ambre', body: '#D97706', head: '#B45309', border: '#92400E', highlight: '#FCD34D' },
  { name: 'Émeraude', body: '#059669', head: '#047857', border: '#065F46', highlight: '#6EE7B7' },
  { name: 'Violet', body: '#7C3AED', head: '#6D28D9', border: '#5B21B6', highlight: '#C4B5FD' },
  { name: 'Turquoise', body: '#0D9488', head: '#0F766E', border: '#115E59', highlight: '#5EEAD4' },
];

export const BOARD_W = 360;
export const BOARD_H = 500;
export const PIN_RADIUS = 12;

export interface Point {
  x: number;
  y: number;
}

export interface Pin {
  id: number;
  /** Tail endpoint */
  x: number;
  y: number;
  /** Exit direction in radians */
  angle: number;
  /** Length from tail to head center */
  length: number;
  radius: number;
  colorIndex: number;
  /** Runtime animation state */
  offset: number;
  status: 'idle' | 'exiting' | 'bouncing' | 'removed';
  bounceProgress: number;
  bounceMax: number;
  flashTimer: number;
}

export interface BlockCheckResult {
  blockedById: number;
  hitDistance: number;
  impactPoint: Point;
}

export interface LevelConfig {
  level: number;
  targetPins: number;
  angleSteps: number;
  minLength: number;
  maxLength: number;
  blockingRiskLabel: string;
  coinReward: number;
}

export function getLevelConfig(level: number): LevelConfig {
  const targetPins = Math.min(22, 4 + Math.floor((level - 1) * 1.45));
  const angleSteps = level <= 2 ? 4 : level <= 5 ? 8 : 12;
  const minLength = level <= 3 ? 72 : 58;
  const maxLength = level <= 3 ? 98 : 112;
  const coinReward = 20 + Math.min(60, (level - 1) * 5);

  let blockingRiskLabel = 'Modéré';
  if (level >= 3 && level <= 5) blockingRiskLabel = 'Élevé';
  else if (level >= 6 && level <= 9) blockingRiskLabel = 'Complexe';
  else if (level >= 10) blockingRiskLabel = 'Expert';

  return {
    level,
    targetPins,
    angleSteps,
    minLength,
    maxLength,
    blockingRiskLabel,
    coinReward,
  };
}

export function getPinEndpoints(pin: Pick<Pin, 'x' | 'y' | 'angle' | 'length'>, extraOffset = 0): { a: Point; b: Point } {
  const dx = Math.cos(pin.angle);
  const dy = Math.sin(pin.angle);
  return {
    a: { x: pin.x + dx * extraOffset, y: pin.y + dy * extraOffset },
    b: { x: pin.x + dx * (pin.length + extraOffset), y: pin.y + dy * (pin.length + extraOffset) },
  };
}

export function pointToSegmentDistSq(p: Point, a: Point, b: Point): number {
  const vx = b.x - a.x;
  const vy = b.y - a.y;
  const wx = p.x - a.x;
  const wy = p.y - a.y;
  const lenSq = vx * vx + vy * vy;
  if (lenSq === 0) return wx * wx + wy * wy;
  const t = Math.max(0, Math.min(1, (wx * vx + wy * vy) / lenSq));
  const projX = a.x + t * vx;
  const projY = a.y + t * vy;
  const dx = p.x - projX;
  const dy = p.y - projY;
  return dx * dx + dy * dy;
}

export function segmentToSegmentDistSq(p1: Point, p2: Point, q1: Point, q2: Point): number {
  const uX = p2.x - p1.x;
  const uY = p2.y - p1.y;
  const vX = q2.x - q1.x;
  const vY = q2.y - q1.y;
  const wX = p1.x - q1.x;
  const wY = p1.y - q1.y;

  const a = uX * uX + uY * uY;
  const b = uX * vX + uY * vY;
  const c = vX * vX + vY * vY;
  const d = uX * wX + uY * wY;
  const e = vX * wX + vY * wY;
  const D = a * c - b * b;

  let sc: number;
  let sN: number;
  let sD = D;
  let tc: number;
  let tN: number;
  let tD = D;

  const EPS = 1e-6;
  if (D < EPS) {
    sN = 0;
    sD = 1;
    tN = e;
    tD = c;
  } else {
    sN = b * e - c * d;
    tN = a * e - b * d;
    if (sN < 0) {
      sN = 0;
      tN = e;
      tD = c;
    } else if (sN > sD) {
      sN = sD;
      tN = e + b;
      tD = c;
    }
  }

  if (tN < 0) {
    tN = 0;
    if (-d < 0) sN = 0;
    else if (-d > a) sN = sD;
    else {
      sN = -d;
      sD = a;
    }
  } else if (tN > tD) {
    tN = tD;
    if (-d + b < 0) sN = 0;
    else if (-d + b > a) sN = sD;
    else {
      sN = -d + b;
      sD = a;
    }
  }

  sc = Math.abs(sN) < EPS ? 0 : sN / sD;
  tc = Math.abs(tN) < EPS ? 0 : tN / tD;

  const dPx = wX + sc * uX - tc * vX;
  const dPy = wY + sc * uY - tc * vY;
  return dPx * dPx + dPy * dPy;
}

/**
 * Checks whether moving `pin` along its extraction vector hits any pin in `others`.
 * Returns null if the exit path is completely clear.
 */
export function findBlockingPin(pin: Pin, others: Pin[], sweepStep = 3): BlockCheckResult | null {
  const MAX_EXIT = 620;
  const dx = Math.cos(pin.angle);
  const dy = Math.sin(pin.angle);

  let earliestHit: BlockCheckResult | null = null;

  for (const other of others) {
    if (other.id === pin.id || other.status === 'removed' || other.status === 'exiting') continue;

    const minDist = pin.radius + other.radius - 1.5;
    const minDistSq = minDist * minDist;
    const otherSeg = getPinEndpoints(other, other.offset);

    const upperBound = earliestHit ? earliestHit.hitDistance : MAX_EXIT;

    for (let t = 0; t <= upperBound; t += sweepStep) {
      const a: Point = { x: pin.x + dx * (pin.offset + t), y: pin.y + dy * (pin.offset + t) };
      const b: Point = {
        x: pin.x + dx * (pin.length + pin.offset + t),
        y: pin.y + dy * (pin.length + pin.offset + t),
      };

      if (segmentToSegmentDistSq(a, b, otherSeg.a, otherSeg.b) < minDistSq) {
        // Binary refine between t - sweepStep and t
        let lo = Math.max(0, t - sweepStep);
        let hi = t;
        for (let iter = 0; iter < 7; iter++) {
          const mid = (lo + hi) * 0.5;
          const ma: Point = { x: pin.x + dx * (pin.offset + mid), y: pin.y + dy * (pin.offset + mid) };
          const mb: Point = {
            x: pin.x + dx * (pin.length + pin.offset + mid),
            y: pin.y + dy * (pin.length + pin.offset + mid),
          };
          if (segmentToSegmentDistSq(ma, mb, otherSeg.a, otherSeg.b) < minDistSq) {
            hi = mid;
          } else {
            lo = mid;
          }
        }
        const hitDist = Math.max(0, lo);
        const impactPoint: Point = {
          x: pin.x + dx * (pin.length + pin.offset + hitDist),
          y: pin.y + dy * (pin.length + pin.offset + hitDist),
        };
        earliestHit = {
          blockedById: other.id,
          hitDistance: hitDist,
          impactPoint,
        };
        break;
      }
    }
  }

  return earliestHit;
}

export function getFreePinIds(pins: Pin[]): number[] {
  const active = pins.filter((p) => p.status !== 'removed' && p.status !== 'exiting');
  const freeIds: number[] = [];
  for (const pin of active) {
    if (!findBlockingPin(pin, active, 4)) {
      freeIds.push(pin.id);
    }
  }
  return freeIds;
}

/**
 * Generates a guaranteed 100%-solvable puzzle via reverse constructive placement.
 * Each added pin can escape cleanly over all previously placed pins, and prefers
 * positions that intentionally block earlier pins to heighten puzzle depth.
 */
export function generateLevelPins(level: number): Pin[] {
  const config = getLevelConfig(level);
  const pad = 34;
  const centerX = BOARD_W / 2;
  const centerY = BOARD_H / 2;

  const anglePool: number[] = [];
  for (let i = 0; i < config.angleSteps; i++) {
    anglePool.push((i * Math.PI * 2) / config.angleSteps);
  }

  let bestBoard: Pin[] = [];

  // Run up to 2 attempts if we got very few pins placed
  for (let attempt = 0; attempt < 2; attempt++) {
    const placed: Pin[] = [];

    for (let i = 0; i < config.targetPins; i++) {
      let bestCandidate: Pin | null = null;
      let bestScore = -Infinity;

      const sampleCount = 55;
      for (let s = 0; s < sampleCount; s++) {
        const length = config.minLength + Math.random() * (config.maxLength - config.minLength);
        const angle = anglePool[Math.floor(Math.random() * anglePool.length)];
        const dx = Math.cos(angle);
        const dy = Math.sin(angle);

        // Spread tighter early, wider as board fills
        const spreadScale = Math.min(1, 0.55 + placed.length * 0.04);
        const halfW = (BOARD_W * 0.5 - pad) * spreadScale;
        const halfH = (BOARD_H * 0.5 - pad) * spreadScale;

        const midX = centerX + (Math.random() * 2 - 1) * halfW;
        const midY = centerY + (Math.random() * 2 - 1) * halfH;

        const x = midX - dx * (length * 0.5);
        const y = midY - dy * (length * 0.5);
        const headX = x + dx * length;
        const headY = y + dy * length;

        // Keep both ends cleanly inside board bounds
        if (
          x < pad || x > BOARD_W - pad ||
          y < pad || y > BOARD_H - pad ||
          headX < pad || headX > BOARD_W - pad ||
          headY < pad || headY > BOARD_H - pad
        ) {
          continue;
        }

        const candidate: Pin = {
          id: i + 1,
          x,
          y,
          angle,
          length,
          radius: PIN_RADIUS,
          colorIndex: i % PIN_PALETTE.length,
          offset: 0,
          status: 'idle',
          bounceProgress: 0,
          bounceMax: 0,
          flashTimer: 0,
        };

        const candSeg = getPinEndpoints(candidate);

        // 1. Ensure no rest overlap with existing pins
        let overlaps = false;
        const restGap = PIN_RADIUS * 2 + 7;
        const restGapSq = restGap * restGap;
        for (const existing of placed) {
          const exSeg = getPinEndpoints(existing);
          if (segmentToSegmentDistSq(candSeg.a, candSeg.b, exSeg.a, exSeg.b) < restGapSq) {
            overlaps = true;
            break;
          }
        }
        if (overlaps) continue;

        // 2. Reverse solvability invariant: candidate must be able to exit cleanly past all pins in `placed`
        if (findBlockingPin(candidate, placed, 6) !== null) {
          continue;
        }

        // 3. Score candidate by how many earlier pins it blocks (creates real dependency chains!)
        let blocksCount = 0;
        for (const existing of placed) {
          if (findBlockingPin(existing, [candidate], 8) !== null) {
            blocksCount++;
          }
        }

        const distFromCenter = Math.hypot(midX - centerX, midY - centerY);
        const blockingWeight = level <= 2 ? 12 : 24;
        const score = blocksCount * blockingWeight - distFromCenter * 0.08 + Math.random() * 2;

        if (score > bestScore) {
          bestScore = score;
          bestCandidate = candidate;
        }

        // Fast early exit if we found an ideal interlocking pin
        if (blocksCount >= (level >= 5 ? 2 : 1) && distFromCenter < 110) {
          break;
        }
      }

      if (bestCandidate) {
        placed.push(bestCandidate);
      }
    }

    if (placed.length > bestBoard.length) {
      bestBoard = placed;
    }
    if (bestBoard.length >= Math.max(4, config.targetPins - 1)) {
      break;
    }
  }

  // Shuffle color assignment slightly so adjacent dependencies aren't predictable by index
  const colorOffset = Math.floor(Math.random() * PIN_PALETTE.length);
  return bestBoard.map((pin, idx) => ({
    ...pin,
    colorIndex: (idx + colorOffset) % PIN_PALETTE.length,
  }));
}

export function findTappedPin(pins: Pin[], pt: Point): Pin | null {
  let bestPin: Pin | null = null;
  let bestDistSq = Infinity;
  // Generous touch hitbox (at least 22px radius around center line => 44px touch width)
  const hitRadius = 22;
  const hitRadiusSq = hitRadius * hitRadius;

  for (let i = pins.length - 1; i >= 0; i--) {
    const pin = pins[i];
    if (pin.status !== 'idle') continue;
    const seg = getPinEndpoints(pin, pin.offset);
    const dSq = pointToSegmentDistSq(pt, seg.a, seg.b);
    if (dSq <= hitRadiusSq && dSq < bestDistSq) {
      bestDistSq = dSq;
      bestPin = pin;
    }
  }
  return bestPin;
}
