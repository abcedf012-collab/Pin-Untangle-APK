import { Capacitor, registerPlugin } from '@capacitor/core';

interface StartIoPluginInterface {
  initialize(options: {
    appId?: string;
    isTesting: boolean;
  }): Promise<{ initialized: boolean; reason?: string }>;
  showBanner(): Promise<{ shown: boolean }>;
  hideBanner(): Promise<void>;
  showInterstitial(): Promise<{ shown: boolean }>;
  showRewardedVideo(): Promise<{
    outcome: 'REWARDED' | 'DISMISSED' | 'UNAVAILABLE' | 'UNCONFIGURED';
  }>;
}

const StartIo = registerPlugin<StartIoPluginInterface>('StartIo');

const STARTIO_APP_ID = (import.meta.env.VITE_STARTIO_APP_ID || '').trim();
const IS_TESTING = import.meta.env.VITE_STARTIO_TESTING === 'true';

let initialized = false;
let configured = false;

export function isNativeMobile(): boolean {
  return Capacitor.isNativePlatform();
}

export async function initStartIo(): Promise<void> {
  if (!isNativeMobile() || initialized) return;
  try {
    const res = await StartIo.initialize({
      appId: STARTIO_APP_ID || undefined,
      isTesting: IS_TESTING,
    });
    initialized = true;
    configured = Boolean(res?.initialized);
    if (configured) {
      await StartIo.showBanner();
    }
  } catch {
    // Ignore SDK init errors so the game always remains playable
  }
}

export async function showNativeInterstitial(): Promise<void> {
  if (!isNativeMobile() || !configured) return;
  try {
    await StartIo.showInterstitial();
  } catch {
    // Ignore if ad failed to load or offline
  }
}

export type RewardedAdOutcome =
  | 'REWARDED'
  | 'DISMISSED'
  | 'UNAVAILABLE'
  | 'UNCONFIGURED';

export async function showNativeRewardedAd(): Promise<RewardedAdOutcome> {
  if (!isNativeMobile()) return 'UNAVAILABLE';
  if (!configured) {
    await initStartIo();
    if (!configured) return 'UNCONFIGURED';
  }
  try {
    const res = await StartIo.showRewardedVideo();
    return res?.outcome || 'UNAVAILABLE';
  } catch {
    return 'UNAVAILABLE';
  }
}
