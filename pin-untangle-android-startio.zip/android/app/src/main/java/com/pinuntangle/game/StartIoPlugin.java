package com.pinuntangle.game;

import android.app.Activity;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.startapp.sdk.ads.banner.Banner;
import com.startapp.sdk.ads.banner.BannerListener;
import com.startapp.sdk.adsbase.Ad;
import com.startapp.sdk.adsbase.StartAppAd;
import com.startapp.sdk.adsbase.StartAppSDK;
import com.startapp.sdk.adsbase.adlisteners.AdDisplayListener;
import com.startapp.sdk.adsbase.adlisteners.AdEventListener;
import com.startapp.sdk.adsbase.adlisteners.VideoListener;
import java.util.concurrent.atomic.AtomicBoolean;

@CapacitorPlugin(name = "StartIo")
public class StartIoPlugin extends Plugin {

    private boolean sdkInitialized = false;
    private Banner bottomBanner = null;
    private FrameLayout bannerContainer = null;

    @PluginMethod
    public void initialize(PluginCall call) {
        String passedId = call.getString("appId", "");
        String resolvedId = passedId != null ? passedId.trim() : "";
        if (resolvedId.isEmpty()) {
            try {
                resolvedId = getContext().getString(R.string.startio_app_id).trim();
            } catch (Exception ignored) {
                resolvedId = "";
            }
        }

        if (resolvedId.isEmpty()) {
            JSObject result = new JSObject();
            result.put("initialized", false);
            result.put("reason", "MISSING_APP_ID");
            call.resolve(result);
            return;
        }

        final String finalAppId = resolvedId;
        final boolean isTesting = Boolean.TRUE.equals(call.getBoolean("isTesting", true));
        Activity activity = getActivity();
        if (activity == null) {
            JSObject result = new JSObject();
            result.put("initialized", false);
            result.put("reason", "NO_ACTIVITY");
            call.resolve(result);
            return;
        }

        activity.runOnUiThread(() -> {
            try {
                StartAppSDK.init(activity.getApplicationContext(), finalAppId, false);
                StartAppSDK.setTestAdsEnabled(isTesting);
                sdkInitialized = true;
                JSObject result = new JSObject();
                result.put("initialized", true);
                call.resolve(result);
            } catch (Exception ex) {
                JSObject result = new JSObject();
                result.put("initialized", false);
                result.put("reason", ex.getMessage());
                call.resolve(result);
            }
        });
    }

    @PluginMethod
    public void showBanner(PluginCall call) {
        if (!sdkInitialized) {
            JSObject result = new JSObject();
            result.put("shown", false);
            call.resolve(result);
            return;
        }

        Activity activity = getActivity();
        if (activity == null) {
            JSObject result = new JSObject();
            result.put("shown", false);
            call.resolve(result);
            return;
        }

        activity.runOnUiThread(() -> {
            try {
                ViewGroup rootView = activity.findViewById(android.R.id.content);
                if (rootView == null) {
                    JSObject result = new JSObject();
                    result.put("shown", false);
                    call.resolve(result);
                    return;
                }

                if (bannerContainer == null) {
                    bannerContainer = new FrameLayout(activity);
                    FrameLayout.LayoutParams containerParams = new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.WRAP_CONTENT,
                        FrameLayout.LayoutParams.WRAP_CONTENT,
                        Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL
                    );
                    bannerContainer.setLayoutParams(containerParams);

                    ViewCompat.setOnApplyWindowInsetsListener(bannerContainer, (v, insets) -> {
                        Insets navBars = insets.getInsets(WindowInsetsCompat.Type.navigationBars());
                        ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) v.getLayoutParams();
                        if (lp != null) {
                            lp.bottomMargin = navBars.bottom;
                            v.setLayoutParams(lp);
                        }
                        return insets;
                    });

                    bottomBanner = new Banner(activity, new BannerListener() {
                        @Override
                        public void onReceiveAd(View view) {
                            if (bannerContainer != null) {
                                bannerContainer.setVisibility(View.VISIBLE);
                            }
                        }

                        @Override
                        public void onFailedToReceiveAd(View view) {}

                        @Override
                        public void onImpression(View view) {}

                        @Override
                        public void onClick(View view) {}
                    });

                    bannerContainer.addView(bottomBanner);
                    rootView.addView(bannerContainer);
                    ViewCompat.requestApplyInsets(bannerContainer);
                } else {
                    bannerContainer.setVisibility(View.VISIBLE);
                }

                if (bottomBanner != null) {
                    bottomBanner.loadAd();
                }

                JSObject result = new JSObject();
                result.put("shown", true);
                call.resolve(result);
            } catch (Exception ex) {
                JSObject result = new JSObject();
                result.put("shown", false);
                call.resolve(result);
            }
        });
    }

    @PluginMethod
    public void hideBanner(PluginCall call) {
        Activity activity = getActivity();
        if (activity != null && bannerContainer != null) {
            activity.runOnUiThread(() -> {
                if (bannerContainer != null) {
                    bannerContainer.setVisibility(View.GONE);
                }
                call.resolve();
            });
        } else {
            call.resolve();
        }
    }

    @PluginMethod
    public void showInterstitial(PluginCall call) {
        if (!sdkInitialized) {
            JSObject result = new JSObject();
            result.put("shown", false);
            call.resolve(result);
            return;
        }

        Activity activity = getActivity();
        if (activity == null) {
            JSObject result = new JSObject();
            result.put("shown", false);
            call.resolve(result);
            return;
        }

        activity.runOnUiThread(() -> {
            final AtomicBoolean resolved = new AtomicBoolean(false);
            StartAppAd interstitial = new StartAppAd(activity);
            interstitial.loadAd(StartAppAd.AdMode.AUTOMATIC, new AdEventListener() {
                @Override
                public void onReceiveAd(Ad ad) {
                    boolean shown = interstitial.showAd(new AdDisplayListener() {
                        @Override
                        public void adHidden(Ad ad) {
                            if (resolved.compareAndSet(false, true)) {
                                JSObject result = new JSObject();
                                result.put("shown", true);
                                call.resolve(result);
                            }
                        }

                        @Override
                        public void adDisplayed(Ad ad) {}

                        @Override
                        public void adClicked(Ad ad) {}

                        @Override
                        public void adNotDisplayed(Ad ad) {
                            if (resolved.compareAndSet(false, true)) {
                                JSObject result = new JSObject();
                                result.put("shown", false);
                                call.resolve(result);
                            }
                        }
                    });
                    if (!shown && resolved.compareAndSet(false, true)) {
                        JSObject result = new JSObject();
                        result.put("shown", false);
                        call.resolve(result);
                    }
                }

                @Override
                public void onFailedToReceiveAd(Ad ad) {
                    if (resolved.compareAndSet(false, true)) {
                        JSObject result = new JSObject();
                        result.put("shown", false);
                        call.resolve(result);
                    }
                }
            });
        });
    }

    @PluginMethod
    public void showRewardedVideo(PluginCall call) {
        if (!sdkInitialized) {
            JSObject result = new JSObject();
            result.put("outcome", "UNCONFIGURED");
            call.resolve(result);
            return;
        }

        Activity activity = getActivity();
        if (activity == null) {
            JSObject result = new JSObject();
            result.put("outcome", "UNAVAILABLE");
            call.resolve(result);
            return;
        }

        activity.runOnUiThread(() -> {
            final AtomicBoolean rewarded = new AtomicBoolean(false);
            final AtomicBoolean resolved = new AtomicBoolean(false);
            StartAppAd rewardedAd = new StartAppAd(activity);

            rewardedAd.setVideoListener(new VideoListener() {
                @Override
                public void onVideoCompleted() {
                    rewarded.set(true);
                }
            });

            rewardedAd.loadAd(StartAppAd.AdMode.REWARDED_VIDEO, new AdEventListener() {
                @Override
                public void onReceiveAd(Ad ad) {
                    boolean shown = rewardedAd.showAd(new AdDisplayListener() {
                        @Override
                        public void adHidden(Ad ad) {
                            if (resolved.compareAndSet(false, true)) {
                                JSObject result = new JSObject();
                                result.put("outcome", rewarded.get() ? "REWARDED" : "DISMISSED");
                                call.resolve(result);
                            }
                        }

                        @Override
                        public void adDisplayed(Ad ad) {}

                        @Override
                        public void adClicked(Ad ad) {}

                        @Override
                        public void adNotDisplayed(Ad ad) {
                            if (resolved.compareAndSet(false, true)) {
                                JSObject result = new JSObject();
                                result.put("outcome", "UNAVAILABLE");
                                call.resolve(result);
                            }
                        }
                    });
                    if (!shown && resolved.compareAndSet(false, true)) {
                        JSObject result = new JSObject();
                        result.put("outcome", "UNAVAILABLE");
                        call.resolve(result);
                    }
                }

                @Override
                public void onFailedToReceiveAd(Ad ad) {
                    if (resolved.compareAndSet(false, true)) {
                        JSObject result = new JSObject();
                        result.put("outcome", "UNAVAILABLE");
                        call.resolve(result);
                    }
                }
            });
        });
    }
}
